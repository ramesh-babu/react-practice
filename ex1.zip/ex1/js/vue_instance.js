
Vue.component('vue-multiselect', window.VueMultiselect.default);
var app = new Vue({
  el: '#app',
  data: {
    filterCriteria: ['Prajwal Rai', 'Ramesh', 'Gopal', 'Kiran Rai'],
    profile: null,
    profileClone: null,
    checkedLocations: []
  },
  created: function () {
    this.fetchData();
  },
  methods: {
    fetchData: function () {
      this.profile = [
        { id: '1', name: 'Prajwal Rai', phone: '9989351973', location: 'Hyderabad', department: 'Software Developer', DOB: '13/108/1991' },
        { id: '2', name: 'Ramesh', phone: '8898454566', location: 'Hyderabad', department: 'Software Developer', DOB: '12/10/1985' },
        { id: '3', name: 'Gopal', phone: '7022975845', location: 'Amalapuram', department: 'Software Testing', DOB: '16/09/1990' },
        { id: '4', name: 'Kiran Rai', phone: '9733150280', location: 'Banglore', department: 'Quality Assurance', DOB: '12/06/1989' },
        { id: '5', name: 'Prajwal Rai', phone: '9989351973', location: 'Hyderabad', department: 'Software Developer', DOB: '13/108/1991' },
        { id: '6', name: 'Ramesh', phone: '8898454566', location: 'Hyderabad', department: 'Software Developer', DOB: '12/10/1985' },
        { id: '7', name: 'Gopal', phone: '7022975845', location: 'Amalapuram', department: 'Software Testing', DOB: '16/09/1990' },
        { id: '8', name: 'Kiran Rai', phone: '9733150280', location: 'Banglore', department: 'Quality Assurance', DOB: '12/06/1989' }
      ];
      this.profileClone = this.profile;
    },
    filterProfile: function (event) {
      app.profileClone = app.profile.filter(function (prof) {
        return app.checkedLocations.includes(prof.name);
      });
    }
  }
})