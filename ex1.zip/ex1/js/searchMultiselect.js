
      

document.addEventListener('DOMContentLoaded', function () { 
Vue.component('vue-multiselect', window.VueMultiselect.default);
// const ach = ['Ramesh', 'Prajwal', 'Gopal'];
new Vue({
    el: '#app',
    data: {
        value: '',
        options: ['Ramesh', 'Prajwal', 'Gopal']
    }
})
})
