var app = new Vue({
    el: '#login',
    data: {
        form : {
            username: '',
            password: ''
          }
    },
    methods: {
      fetchLoginData: function () {
        axios.get('http://localhost:8080/php-api/api/User/login.php?username='+this.form.username+'&password='+this.form.password)
        .then(function (response) {
          console.log(response);
          // this.$router.push("/index.html");
        })
        .catch(function (error) {
          console.log(error);
        });
      }
    }
  })