<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/user.php';


$conArray = [
    [
        'host' => 'localhost',
        'dbname' => 'sample2',
        'dbusername' => 'root',
        'dbpassword' => '',
        'dbtype' => 'connectmysql',
        'tablename' => 'users'
    ],
    [
        'host' => 'localhost',
        'dbname' => 'd7-practice',
        'dbusername' => 'root',
        'dbpassword' => '',
        'dbtype' => 'drupalmysql',
        'tablename' => 'users'
    ]
];

foreach($conArray as $cona) {
    // get database connection
    $database = new Database();
    $db = $database->getConnection($cona);
    
    // prepare user object
    $user = new User($db);
    // set ID property of user to be edited
    $user->username = isset($_GET['username']) ? $_GET['username'] : die();

    // print_r($cona[dbtype]); exit;

    if($cona['dbtype'] == 'connectmysql') {
        $user->password = base64_encode(isset($_GET['password']) ? $_GET['password'] : die());
    }
    elseif($cona['dbtype'] == 'drupalmysql') {
        // $user->password = hash("sha512", $_GET['password']);

        // generate a 16-character salt string
        $salt = substr(str_replace('+','.',base64_encode(md5(mt_rand(), true))),0,16);
        // how many times the string will be hashed
        $rounds = 10000;
        // pass in the password, the number of rounds, and the salt
        // $5$ specifies SHA256-CRYPT, use $6$ if you really want SHA512
        echo crypt($_GET['password'], sprintf('$5$rounds=%d$%s$', $rounds, $salt));
        exit;
    }
    // print $user->password; exit;
    // read the details of user to be edited
    $stmt = $user->login($cona['tablename'], $cona['dbtype']);
    if($stmt->rowCount() > 0){
        // get retrieved row
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        // create array
        $user_arr=array(
            "status" => true,
            "message" => "Successfully Login!",
            "id" => $row['id'],
            "username" => $row['username']
        );
        print_r(json_encode($user_arr));
        exit;    
    }
    
    else{
        $user_arr=array(
            "status" => false,
            "message" => "Invalid Username or Password!",
            "dbdetails" => print_r($cona)
        );
        print_r(json_encode($user_arr));
    }
    // make it json format
    
}


?>